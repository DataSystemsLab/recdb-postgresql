CREATE TABLE users (systemid serial, PRIMARY KEY (systemId), itemid int not null, name varchar, type varchar);
CREATE TABLE items (ratingid serial, PRIMARY KEY (ratingId), userid int not null, itemid int not null, ratingval real, ratingts real);
CREATE TABLE ratings (ratingid serial, PRIMARY KEY (ratingId), userid int not null, itemid int not null, ratingval real, ratingts real);

copy users from '/Users/sarwat/Desktop/EclipseJavaWorkSpace/Recathon/commands/data/MovieLens1M/users.dat' DELIMITERS '::' CSV;
copy items from '/Users/sarwat/Desktop/EclipseJavaWorkSpace/Recathon/commands/data/MovieLens1M/items.dat' DELIMITERS '::' CSV;
copy ratings from '/Users/sarwat/Desktop/EclipseJavaWorkSpace/Recathon/commands/data/MovieLens1M/ratings.dat' DELIMITERS '::' CSV;

