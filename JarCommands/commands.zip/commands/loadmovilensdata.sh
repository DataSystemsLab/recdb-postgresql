#!/bin/bash
./createrecommender.py -recmodelname=GenderRecommender -userattrs=gender -recmethod=1
./createrecommender.py -recmodelname=JobRecommender -userattrs=job -recmethod=1
./createrecommender.py -recmodelname=AgeRecommender -userattrs=age -recmethod=1
./createrecommender.py -recmodelname=GenderJobRecommender -userattrs=gender,job -recmethod=1
./createrecommender.py -recmodelname=GenderAgeRecommender -userattrs=gender,age -recmethod=1
./createrecommender.py -recmodelname=JobAgeRecommender -userattrs=job,age -recmethod=1
./createrecommender.py -recmodelname=GenderJobAgeRecommender -userattrs=gender,job,age -recmethod=1